1. cd vrep_scenes and open the scene file iiwa14_computed_torque.ttt
2. start MATLAB and run adddir.m
3. cd iiwa14_computed_torque_control and run iiwa14_computer_torque_control.m

NOTE: this sample is an adaptation of the sample provided by Mathworks
      if you have network connection, you can click this link https://ww2.mathworks.cn/help/robotics/examples/control-lbr-manipulator-motion-through-joint-torque.html?s_tid=srchtitle
      if you have locally installed matlab help files , you can examine the original sample in MATLAB (附加功能->管理附加功能->Robotics System Toolbox->右侧选择“打开文档”->Manipulator Algorithm Design->Trajectory Generation and Following->Control LBR Manipulator Motion Through Joint Torque Commands)

enjoy it!